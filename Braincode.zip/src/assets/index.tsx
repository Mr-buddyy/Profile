import climateaware from "./images/website-climateaware.png";
import desa from "./images/website-desa.png";
import event from "./images/website-event.png";
import gamis from "./images/website-gamis.png";
import stoik from "./images/website-stoik.png";
import foto from "./images/3x4.jpeg";
import logo from "./images/1110.jpg";

export { climateaware, desa, event, gamis, stoik, foto, logo };
