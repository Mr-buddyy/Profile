import Home from "./home";
import Contact from "./contact";
import About from "./about";
import Portofolio from "./portofolio";

export { Home, Contact, About, Portofolio };
